#include<stdio.h>

enum mois {janvier, fervrier, mars, avril, mai, juin, juillet,aout,spetembre,octobre,novembre,decembre};

struct date{
    int jour;
    mois sp;
    int année;
    

};


void jours_ecoules(date z){
    
    date mystructesp[12];

}


int main(void){
    int dates;
    date z = jour();
    printf("%d",jour());
    
}
