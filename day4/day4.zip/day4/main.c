#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include"complex.h"


int main(void){
    
    
    
    
    return 0;
}


